use farms;
CREATE DATABASE farms;

CREATE TABLE produto 
( 
 data_validade date not null,  
 fabricante varchar(100) not null,  
 preco float not null,  
 id_produto INT PRIMARY KEY auto_increment not null,  
 nome varchar(100) not null,  
 categoria varchar(100) not null,  
 descricao varchar(100) not null,  
 
 id_estoque INT not null,  
 id_entrega INT not null
); 

ALTER TABLE produto ADD FOREIGN KEY (id_estoque) REFERENCES estoque(id_estoque);
ALTER TABLE produto ADD FOREIGN KEY (id_entrega) REFERENCES entrega(id_entrega);



CREATE TABLE cliente
( 
 id_cliente INT PRIMARY KEY not null,  
 nome varchar(100) not null,  
 cpf varchar(11) not null,  
 rua varchar(100) not null,  
 numero varchar(11) not null,  
 
 id_programa int not null
 ); 

ALTER TABLE cliente ADD FOREIGN KEY (id_programa) REFERENCES programa_de_fidelidade(id_programa);



CREATE TABLE transacao_de_venda 
( 
 id_transacao INT PRIMARY KEY auto_increment not null,  
 data_ varchar(100),  
 produto_vendido varchar(100) not null,  
 metodo_pag varchar(100) not null,  
 preco_total int not null,  
 
 rg INT not null,  
 id_cliente INT not null
); 

ALTER TABLE transacao_de_venda ADD FOREIGN KEY (rg) REFERENCES funcionario(rg);
ALTER TABLE transacao_de_venda ADD FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);


CREATE TABLE receita_medica 
( 
 id_receita INT PRIMARY KEY auto_increment not null,  
 data_prescricao date not null,  
 medicamento_prescricao varchar(100) not null,  
 duracao_prescricao varchar(100) not null,  
 
 id_cliente INT not null  
); 

ALTER TABLE receita_medica ADD FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);


CREATE TABLE entrega 
( 
 id_entrega INT PRIMARY KEY auto_increment not null,  
 valor float not null,  
 tipo varchar(100) not null,  
 data_validade date not null,  
 
 id_cliente INT not null,  
 id_receita INT not null  
); 

ALTER TABLE entrega ADD FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);
ALTER TABLE entrega ADD FOREIGN KEY (id_receita) REFERENCES receita_medica(id_receita);


CREATE TABLE programa_de_fidelidade 
( 
 nome_programa varchar(800) not null,  
 id_programa INT PRIMARY KEY auto_increment not null,  
 descricao varchar(800) not null,  
 beneficios varchar(800) not null,  
 regras_de_pontuacao varchar(800) not null,  
 historico varchar(800) not null
); 

ALTER TABLE programa_de_fidelidade modify historico varchar(800);

CREATE TABLE fornecedor 
( 
 id_fornecedor INT PRIMARY KEY auto_increment not null,  
 nome varchar(100) not null,  
 endereco varchar(100) not null,  
 telefone varchar(100) not null,  
 email varchar(100) not null,  
 lote INT not null,  
 lista_produtos varchar(100) not null
); 


CREATE TABLE estoque 
( 
 id_estoque INT PRIMARY KEY auto_increment not null,  
 localidade varchar(100) not null,  
 data_atualizacao date not null
); 



CREATE TABLE funcionario 
( 
 rg INT PRIMARY KEY not null,  
 nome varchar(100) not null,  
 data_contratacao date not null,  
 cargo varchar(100) not null,  
 salario INT not null,  
 telefone INT not null,  
 email varchar(100) not null,  
 
 id_regulamentacao INT not null
); 

ALTER TABLE funcionario ADD FOREIGN KEY (id_regulamentacao) REFERENCES regulamentacao_e_conformidade(id_regulamentacao);


CREATE TABLE regulamentacao_e_conformidade 
( 
 id_regulamentacao INT PRIMARY KEY auto_increment not null,  
 politica_e_privacidade varchar(100) not null,  
 regulamentacao_saude varchar(100) not null,  
 conformidade_regulatoria varchar(100) not null,  
 registro_inspecao varchar(100) not null
); 



CREATE TABLE atribui_receita_produto
( 
 id_receita INT not null,  
 id_produto INT not null
); 

ALTER TABLE atribui_receita_produto ADD FOREIGN KEY (id_receita) REFERENCES receita_medica(id_receita);
ALTER TABLE atribui_receita_produto ADD FOREIGN KEY (id_produto) REFERENCES produto(id_produto);


CREATE TABLE atribui_produto_transacao
( 
 id_produto INT not null,  
 id_transacao INT not null 
); 

ALTER TABLE atribui_produto_transacao ADD FOREIGN KEY (id_produto) REFERENCES produto(id_produto);
ALTER TABLE atribui_produto_transacao ADD FOREIGN KEY (id_transacao) REFERENCES transacao_de_venda(id_transacao);

CREATE TABLE fornece 
( 
 id_fornecedor INT not null,  
 id_produto INT not null
);

ALTER TABLE fornece ADD FOREIGN KEY (id_fornecedor) REFERENCES fornecedor(id_fornecedor);
ALTER TABLE fornece ADD FOREIGN KEY (id_produto) REFERENCES produto(id_produto);
