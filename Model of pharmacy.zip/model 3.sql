use farms;

SELECT * FROM programa_de_fidelidade;
SELECT * FROM cliente;
SELECT * FROM estoque;
SELECT * FROM receita_medica;
SELECT * FROM entrega;
SELECT * FROM regulamentacao_e_conformidade;
SELECT * FROM produto;
SELECT * FROM fornecedor;
SELECT * FROM funcionario;
SELECT * FROM transacao_de_venda;