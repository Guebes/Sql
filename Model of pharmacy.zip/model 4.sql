use farms;

SELECT id_cliente, nome, cpf, rua, numero, 
		nome_programa, descricao, beneficios, regras_de_pontuacao, historico, historico
FROM cliente
JOIN programa_de_fidelidade
ON cliente.id_programa = programa_de_fidelidade.id_programa;
/* ------------------------------------------------------------------------**/

SELECT data_validade, fabricante, preco, nome, categoria, descricao,
		localidade, data_atualizacao
FROM produto
JOIN estoque
ON produto.id_estoque = estoque.id_estoque;

/* ------------------------------------------------------------------------**/

SELECT p.data_validade, p.fabricante, p.preco, p.nome, p.categoria, p.descricao,
    e.valor, e.tipo, e.data_validade
FROM produto p
JOIN entrega e 
ON p.id_entrega = e.id_entrega;

/* ------------------------------------------------------------------------**/

SELECT data_prescricao, medicamento_prescricao, duracao_prescricao,
    nome, cpf, rua, numero
FROM receita_medica 
JOIN cliente 
ON receita_medica.id_cliente = cliente.id_cliente;

/* ------------------------------------------------------------------------**/

SELECT rg, nome, data_contratacao, cargo, salario, telefone, email,
    politica_e_privacidade, regulamentacao_saude, conformidade_regulatoria, registro_inspecao
FROM funcionario 
JOIN regulamentacao_e_conformidade 
ON funcionario.id_regulamentacao = regulamentacao_e_conformidade.id_regulamentacao

/* ------------------------------------------------------------------------**/
